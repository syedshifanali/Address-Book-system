#include "contact.h"

int main()
{
    AddressBook addressbook;
    initialize(&addressbook);
    loadcontacts(&addressbook,"contact.txt");
    int option;
     printf("\n-------ADDRESS BOOK SYSTEM-------\n");
    while(1){
    printf("\n 1. Create Contact\n 2. Search Contact\n 3. Edit Contact\n 4. Delete Contact\n 5. List Contacts\n 6. Saved Contacts\n 7. Exit\n");
    printf("\nEnter the option :");
    scanf("%d",&option);
    switch(option){
        case 1:
        createContact(&addressbook);
        break;
        case 2:
        searchContact(&addressbook);
        break;
        case 3:
        editContact(&addressbook);
        break;
        case 4:
        deleteContact(&addressbook);
        break;
        case 5:
        listContacts(&addressbook);
        break;
        case 6:
        savedcontacts(&addressbook,"contact.txt");
        break;
        case 7:
        printf("Exit the program\n-------THANK YOU-------\n");
        exit(0);
        break;
        default : printf("Invalid Option\n");
        break;
    }
}
   
}
