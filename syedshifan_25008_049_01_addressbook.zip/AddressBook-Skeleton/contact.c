#include "contact.h"
void listContacts(AddressBook *addressBook)
{
    printf("%d contacts\n", addressBook->contactCount);
    printf("\nS.No...Name............Phone...........Email\n");
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        printf("%-5d",i+1);
        printf("%-15s",addressBook->contacts[i].name);
        printf("%-15s",addressBook->contacts[i].phone);
        printf("%s",addressBook->contacts[i].email);
        printf("\n");
    }
}
void createContact(AddressBook *addressBook){
    char name[100];
    char phone[11], email[50];

    printf("Enter the name :");
    scanf(" %[^\n]", name);
    validatename(addressBook, name);

    printf("Enter the phone :");
    scanf(" %[^\n]", phone);
    validatephone(addressBook, phone);

    printf("Enter the Email :");
    scanf(" %[^\n]", email);
    validateemail(addressBook, email);
    addressBook->contactCount++;
    printf("\nContact Created Successfully\n");
}
void searchContact(AddressBook *addressBook)
{
    char name[100], phone[11], email[50];
    printf("Enter the choice to search :\n");
    printf(" 1.Search by Name\n 2.Search by Phone no\n 3.Search by Email Id\n ");
    int choice;
    printf("\nChoose the option to search: ");
    scanf("%d", &choice);
    switch (choice)
    {
    case 1:
        printf("Enter the name to search :\n");
        scanf(" %[^\n]", name);
        int count = 0;
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            validatename(addressBook, addressBook->contacts[i].name);
            if (strcmp(addressBook->contacts[i].name,name)==0)
            {
                count=1;
                printf("\n-------Name found-------\n\nContact details :\n");
                printf("Name: %-10s\nPhone: %-10s\nEmail Id: %s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
            }
        }
        if (count==0)
        {
            printf("Name not found\n");
        }
        break;
    case 2:
        printf("Enter the phone number to search :");
        scanf(" %[^\n]",phone);
        int count1 = 0;
        for (int j=0;j<addressBook->contactCount;j++)
        {
            if (strcmp(phone, addressBook->contacts[j].phone) == 0)
            {
                count1=1;
                printf("\n-------Phone number found-------\n\nContact details :\n");
                printf("Name: %s\nPhone: %s\nEmail Id: %s\n", addressBook->contacts[j].name, addressBook->contacts[j].phone, addressBook->contacts[j].email);
            }
        }
        if (count1==0)
        {
            printf("\nphone number not found\n");
        }
        break;
    case 3:
        printf("Enter the Email to search :");
        scanf(" %[^\n]", email);
        int count2=0;
        for (int k=0; k < addressBook->contactCount; k++)
        {
            if (strcmp(email, addressBook->contacts[k].email) == 0)
            {
                count2=1;
                printf("\n-------Email Id found-------\n\nContact details :\n");
                printf("Name: %s\nPhone: %s\nEmail Id: %s\n", addressBook->contacts[k].name, addressBook->contacts[k].phone, addressBook->contacts[k].email);
            }
        }
        if (count2==0)
        {
            printf("Email not found\n");
        }
        break;
    }
}
void editContact(AddressBook *addressBook)
{
    int edit;
    int arr[addressBook->contactCount];
    printf("Choose the option to Edit:\n");
    printf("1. Edit by Name\n2. Edit by Phone Number\n3. Edit by Email Id\n");
    scanf("%d", &edit);
    char contact[100];
    int foundcont= 0,count=0,i;
    switch (edit)
    {
    case 1:
        printf("Enter Name to Edit: ");
        scanf(" %[^\n]", contact);
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].name, contact) == 0)
            {
                arr[count++]=i;
                foundcont=1;
            }
        }
        break;
    case 2:
        printf("Enter Phone number to Edit: ");
        scanf(" %[^\n]", contact);
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone, contact) == 0)
            {
                arr[count++] = i;
                foundcont= 1;
            }
        }
        break;
    case 3:
        printf("Enter Email Id to Edit: ");
        scanf(" %[^\n]s", contact);
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].email, contact) == 0)
            {
                arr[count++] = i;
                foundcont= 1;
            }
        }
        break;
    default:
        printf("Invalid option\n");
        return;
    }
    if (!foundcont)
    {
        printf("Contact Not Found\n");
        return;
    }
    int index;
    if (count > 1)
    {
        printf("\nMultiple contacts found:\n");
        for (int j = 0; j < count; j++)
        {
            printf("\n%d. Name: %s\nPhone: %s\nEmail: %s\n", j + 1, addressBook->contacts[arr[j]].name, addressBook->contacts[arr[j]].phone, addressBook->contacts[arr[j]].email);
        }
        int choice;
        printf("\nEnter the number to edit: ");
        scanf("%d", &choice);
        if (choice < 1 || choice > count)
        {
            printf("Invalid Choice.\n");
            return;
        }
        index = arr[choice - 1];
    }
    else
    {
        index=arr[0];
        printf("\nContact found:\nName: %s\nPhone: %s\nEmail: %s\n", addressBook->contacts[index].name, addressBook->contacts[index].phone, addressBook->contacts[index].email);
    }
    printf("\nSelect the Option To Edit:\n1. Edit by Name\n2. Edit by Phone\n3. Edit by Email\nEnter your choice: ");
    int select;
    scanf("%d", &select);
    switch (select)
    {
    case 1:
        char name1[100];
        printf("Enter new name: ");
        scanf(" %[^\n]s",name1);
        validatename(addressBook,name1);
        strcpy(addressBook->contacts[index].name,name1);
        printf("\nName edited successfully.\n");
        break;
    case 2:
        char phone1[11];
        printf("Enter new phone: ");
        scanf(" %[^\n]s", phone1);
        validatephone(addressBook,phone1);
        strcpy(addressBook->contacts[index].phone,phone1);
        printf("\nPhone edited successfully.\n");
        break;
    case 3:
    char email1[50];
        printf("Enter new email: ");
        scanf(" %[^\n]s",email1);
        validateemail(addressBook,email1);
        strcpy(addressBook->contacts[index].email,email1);
        printf("\nEmail Id edited successfully.\n");
        break;
    default:
        printf("Invalid choice.\n");
        break;
    }
}
void deleteContact(AddressBook *addressBook)
{
    int option;
    int arr[addressBook->contactCount];
    printf("Choose the option to Delete:\n");
    printf("1. Delete by Name\n2. Delete by Phone Number\n3. Delete by Email Id\n");
    scanf("%d", &option);
    char contact[100];
    int found= 0,count = 0;
    switch (option)
    {
    case 1:
        printf("Enter Name to Delete: ");
        scanf(" %[^\n]s", contact);
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].name, contact) == 0)
            {
                arr[count++] = i;
                found = 1;
            }
        }
        break;
    case 2:
        printf("Enter Phone number to Delete: ");
        scanf(" %[^\n]s", contact);
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone, contact) == 0)
            {
                arr[count++] = i;
                found = 1;
            }
        }
        break;
    case 3:
        printf("Enter Email Id to Delete: ");
        scanf(" %[^\n]", contact);
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].email, contact) == 0)
            {
                arr[count++] = i;
                found = 1;
            }
        }
        break;
    default:
        printf("Invalid option\n");
        return;
    }
    if(found){
    int index;
    if(count>1)
    {
        printf("\nMultiple contacts found:\n");
        for (int j = 0; j < count; j++)
        {
            printf("\n%d. Name: %s\nPhone: %s\nEmail: %s\n", j + 1,addressBook->contacts[arr[j]].name,addressBook->contacts[arr[j]].phone,addressBook->contacts[arr[j]].email);
        }
        int choice;
        printf("\nEnter the number to delete: ");
        scanf("%d", &choice);
        if (choice < 1 || choice > count)
        {
            printf("Invalid Choice.\n");
            return;
        }
        index = arr[choice - 1];
    }
    else
    {
        index = arr[0];
        printf("\nContact found:\nName: %s\nPhone: %s\nEmail: %s\n",addressBook->contacts[index].name,addressBook->contacts[index].phone,addressBook->contacts[index].email);
    }
    for (int i = index; i < addressBook->contactCount - 1; i++) 
    {
        addressBook->contacts[i] = addressBook->contacts[i + 1];
    }
    addressBook->contactCount--;
    printf("\nContact deleted successfully.\n");
}
else{
    printf("Contact not found.\n");
}
}

void validatename(AddressBook *addressBook, char *name){
    int count = 0;
    for (int i = 0; name[i] != '\0'; i++)
    {
        if (!isalpha(name[i]) && name[i] != ' ')
        {
            count = 1;
            break;
        }
    }
    if (!count)
    {
        strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    }
    else
    {
        printf("Enter the valid name :");
        scanf(" %[^\n]", name);
        validatename(addressBook, name);
        return;
    }
}
void validatephone(AddressBook *addressBook, char *phone)
{
    int count1 = 1;
    int length = strlen(phone);
    if (length!= 10)
    {
        count1 = 0;
    }
    else
    {
        for (int i = 0; phone[i] != '\0'; i++)
        {
            if (!isdigit(phone[i]))
            {
                count1 = 0;
                break;
            }
        }
        if(count1){
            for(int i=0;i<addressBook->contactCount;i++){
                if(strcmp(addressBook->contacts[i].phone,phone)==0){
                    count1=0;
                    printf("Phone number already exists.Enter a different phone number: ");
                    scanf(" %[^\n]",phone);
                    validatephone(addressBook,phone);
                    return;
                }
            }
        }
    }
    if (count1)
    {
        strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
    }
    else
    {
        printf("Enter the valid phone no (It should contain only 10 digits) :");
        scanf(" %[^\n]", phone);
        validatephone(addressBook, phone);
        return;
    }
}
void validateemail(AddressBook *addressBook, char *email)
{
    char *required = "@gmail.com";
    int len = strlen(email);
    int ptrlen = strlen(required);
    int flag = 1;
    if (len > ptrlen && strcmp(email + (len - ptrlen), "@gmail.com") == 0)
    {
        for (int i = 0; i < len - ptrlen; i++)
        {
            if (!(islower(email[i]) || isdigit(email[i])))
            {
                flag = 0;
                break;
            }
        }
        if(flag){
            for(int i=0;i<addressBook->contactCount;i++){
                if(strcmp(addressBook->contacts[i].email,email)==0){
                    flag=0;
                    printf("Email Id already exists.Enter a different email id: ");
                    scanf(" %[^\n]",email);
                    validateemail(addressBook,email);
                    return;
                }
            }
        }
        if (flag)
        {
            strcpy(addressBook->contacts[addressBook->contactCount].email, email);
        }
        else{
            printf("Please Enter a valid gmail Id (only lower case alphabets allowed): ");
            scanf(" %[^\n]",email);
            validateemail(addressBook,email);
        }
    }
    else {
    printf("Enter a valid Gmail address :");
    scanf(" %[^\n]", email);
    validateemail(addressBook, email);
}
}
void savedcontacts(AddressBook *addressBook, const char *filename)
{
    FILE *fptr=fopen(filename, "w");
    if (fptr == NULL)
    {
        printf("File not found\n");
        return;
    }
    fprintf(fptr, "#%d\n", addressBook->contactCount);
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fptr, " %s,%s,%s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
    }
    fclose(fptr);
    printf("\nContacts saved successfully.\n");
}
void loadcontacts(AddressBook *addressBook, const char *filename)
{
    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        return;
    }
    fscanf(fptr, "#%d\n", &addressBook->contactCount);
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (fscanf(fptr, " %[^,],%[^,],%[^\n]\n",addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email))
        {
            // addressBook->contactCount++;
        }
        else
        {
            break;
        }
    }
    fclose(fptr);
}

